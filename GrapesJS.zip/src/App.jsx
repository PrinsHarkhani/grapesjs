import WebBuilder from './WebBuilder'

function App() {
  

  return (
    <>
      <div>
        <WebBuilder />
      </div>
      
    </>
  )
}

export default App
