import React, { useEffect } from 'react';
import grapesjs from 'grapesjs';
import 'grapesjs/dist/css/grapes.min.css';
import gjsPresetWebpage from 'grapesjs-preset-webpage';
import gjsPluginExport from 'grapesjs-plugin-export';
import gjsTabs from 'grapesjs-tabs';
import gjsimageeditor from 'grapesjs-tui-image-editor';
import MyCustomPlugin from './MyCustomPlugin';
import 'grapesjs-plugin-forms';
import plugin from 'grapesjs-preset-newsletter';

const WebBuilder = () => {
  useEffect(() => {
    const editor = grapesjs.init({
      container: '#editor',
      // components: '<div class="default-section" data-gjs-type="default-section">This is the default section</div>',
      // style: '.default-section { min-height: 100vh; display: flex; justify-content: center; border: 1px solid #ccc; max-width: 400px; padding: 20px; margin: 0 auto; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); }',
      plugins: [MyCustomPlugin, 'grapesjs-plugin-forms',plugin],
    });
    

    
    
   
    //  // Register the default-section as a droppable component
    // editor.BlockManager.add('default-section', {
    //   label: 'Default Section',
    //   content: '<div class="default-section" data-gjs-type="default-section">This is the default section</div>',
    // });

    // Optional: Add blocks, styles, etc.

    return () => {
      editor.destroy();
    };
  }, []);

  return <div id="editor" />;
};

export default WebBuilder;
