import WebBuilder from './WebBuilder'
import "./Style.css"

function App() {
  

  return (
    <>
      <div>
        <WebBuilder />
      </div>
      
    </>
  )
}

export default App
